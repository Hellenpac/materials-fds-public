OK_FORMAT = True

test = {   'name': 'q1_2_5',
    'points': [0, 1, 1, 1, 1],
    'suites': [   {   'cases': [   {'code': '>>> monthly_increases.num_rows == 12\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> monthly_increases.labels == ('Month', 'Past', 'Present', 'Increase')\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> monthly_increases.row(2).item('Month') == '03 (Mar)'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> np.isclose(monthly_increases.row(2).item('Past'), 74.64992067689053)\nTrue", 'hidden': True, 'locked': False},
                                   {'code': ">>> np.isclose(monthly_increases.row(2).item('Present'), 75.97956989247312)\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
