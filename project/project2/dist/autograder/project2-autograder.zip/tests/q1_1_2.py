OK_FORMAT = True

test = {   'name': 'q1_1_2',
    'points': [0, 2],
    'suites': [   {   'cases': [{'code': '>>> type(answer_q112) == int\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> answer_q112 == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
