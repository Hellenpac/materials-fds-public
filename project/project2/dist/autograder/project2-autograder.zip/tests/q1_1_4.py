OK_FORMAT = True

test = {   'name': 'q1_1_4',
    'points': [1, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5],
    'suites': [   {   'cases': [   {'code': '>>> type(coordinates_to_region(50, 100)) == str\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> coordinates_to_region(41, 10) == 'Northeast'\nTrue", 'hidden': True, 'locked': False},
                                   {'code': ">>> coordinates_to_region(40, -100) == 'Northeast'\nTrue", 'hidden': True, 'locked': False},
                                   {'code': ">>> coordinates_to_region(41, -110) == 'Northwest'\nTrue", 'hidden': True, 'locked': False},
                                   {'code': ">>> coordinates_to_region(10, -110) == 'Southwest'\nTrue", 'hidden': True, 'locked': False},
                                   {'code': ">>> coordinates_to_region(10, 15) == 'Southeast'\nTrue", 'hidden': True, 'locked': False},
                                   {'code': ">>> coordinates_to_region(39, -100) == 'Southeast'\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
