OK_FORMAT = True

test = {   'name': 'q2_2',
    'points': [0, 2],
    'suites': [   {   'cases': [   {'code': '>>> set(answer_q22) == set([1, 2])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> answer_q22 == [2, 1]\narray([ True,  True], dtype=bool)', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
