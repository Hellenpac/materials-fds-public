OK_FORMAT = True

test = {   'name': 'q1_2_9',
    'points': [0, 2],
    'suites': [   {   'cases': [   {'code': '>>> all((x in range(1, 3) for x in set(answer_q129)))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> set(answer_q129) == set([1, 2])\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
