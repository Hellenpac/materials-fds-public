OK_FORMAT = True

test = {   'name': 'q2_5',
    'points': [0, 2],
    'suites': [   {   'cases': [{'code': '>>> type(answer_q25) == int\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> answer_q25 == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
