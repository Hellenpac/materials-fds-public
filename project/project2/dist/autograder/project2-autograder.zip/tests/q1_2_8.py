OK_FORMAT = True

test = {   'name': 'q1_2_8',
    'points': [1, 3],
    'suites': [   {   'cases': [   {'code': '>>> type(months) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': ">>> comparison_results = make_array('**below**', '*above*', '*above*', '**below**', '**below**', '**below**', '**below**', '**below**', '**below**', "
                                               "'**below**', '**below**', '*above*')\n"
                                               '>>> np.all(comparisons == comparison_results)\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
