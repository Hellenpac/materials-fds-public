OK_FORMAT = True

test = {   'name': 'q2_11',
    'points': [0, 2],
    'suites': [   {   'cases': [{'code': '>>> type(answer_211) == int\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> answer_211 == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
