OK_FORMAT = True

test = {   'name': 'q2_1',
    'points': [0, 1, 1, 2],
    'suites': [   {   'cases': [   {'code': '>>> totals.num_rows == 61\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> totals.labels == ('Year', 'Precipitation')\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> list(totals.row(5)) == [1965, 187.53]\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> list(totals.row(59)) == [2019, 172.10000000000002]\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
