OK_FORMAT = True

test = {   'name': 'q2_6',
    'points': [1, 1, 1, 1],
    'suites': [   {   'cases': [   {'code': '>>> observed_statistic < 0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> test_statistic(drought.sample()) != test_statistic(drought.sample())\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> np.isclose(test_statistic(drought), -15.856714743589748)\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> np.isclose(test_statistic(drought), observed_statistic)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
